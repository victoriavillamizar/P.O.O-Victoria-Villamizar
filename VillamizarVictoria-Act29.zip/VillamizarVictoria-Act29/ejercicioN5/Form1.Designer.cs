﻿namespace ejercicioN5
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.crear = new System.Windows.Forms.CheckBox();
            this.modificar = new System.Windows.Forms.CheckBox();
            this.eliminar = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "administrador",
            "editor",
            "invitado"});
            this.comboBox1.Location = new System.Drawing.Point(98, 97);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // crear
            // 
            this.crear.AutoSize = true;
            this.crear.Location = new System.Drawing.Point(98, 124);
            this.crear.Name = "crear";
            this.crear.Size = new System.Drawing.Size(50, 17);
            this.crear.TabIndex = 1;
            this.crear.Text = "crear";
            this.crear.UseVisualStyleBackColor = true;
            // 
            // modificar
            // 
            this.modificar.AutoSize = true;
            this.modificar.Location = new System.Drawing.Point(98, 147);
            this.modificar.Name = "modificar";
            this.modificar.Size = new System.Drawing.Size(68, 17);
            this.modificar.TabIndex = 2;
            this.modificar.Text = "modificar";
            this.modificar.UseVisualStyleBackColor = true;
            // 
            // eliminar
            // 
            this.eliminar.AutoSize = true;
            this.eliminar.Location = new System.Drawing.Point(98, 170);
            this.eliminar.Name = "eliminar";
            this.eliminar.Size = new System.Drawing.Size(61, 17);
            this.eliminar.TabIndex = 3;
            this.eliminar.Text = "eliminar";
            this.eliminar.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.eliminar);
            this.Controls.Add(this.modificar);
            this.Controls.Add(this.crear);
            this.Controls.Add(this.comboBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.CheckBox crear;
        private System.Windows.Forms.CheckBox modificar;
        private System.Windows.Forms.CheckBox eliminar;
    }
}

