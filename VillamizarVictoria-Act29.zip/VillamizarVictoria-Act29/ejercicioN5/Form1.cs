﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicioN5
{
    public partial class Form1 : Form
    {
        /*10. Administrador de Roles y Permisos
        ● Consigna: Incluir un ComboBox con opciones: &quot;Administrador&quot;, &quot;Editor&quot; e &quot;Invitado&quot;.
        En el evento SelectedIndexChanged, modificar dinámicamente la propiedad Enabled
        de tres CheckBox (&quot;Crear&quot;, &quot;Modificar&quot;, &quot;Eliminar&quot;) según el perfil elegido.*/
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "administrador")
            {
                crear.Enabled = true;
                modificar.Enabled = true;
                eliminar.Enabled = true;
            }
            else if (comboBox1.Text == "editor")
            {
                crear.Enabled = true;
                modificar.Enabled = true;
                eliminar.Enabled = false;
            }
            else if (comboBox1.Text == "invitado")
            {
                crear.Enabled = false;
                modificar.Enabled = false;
                eliminar.Enabled = false;
            }
        }
    }
    }

