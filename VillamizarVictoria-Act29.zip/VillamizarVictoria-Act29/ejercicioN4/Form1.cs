﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicioN4
{
    public partial class Form1 : Form
    {
        /*9. Cálculo de Edad (Investigación: DateTimePicker)
        ● Investigación: Investigar el control DateTimePicker (propiedad Value de tipo
        DateTime).
        ● Consigna: Permitir que el usuario elija su fecha de nacimiento. Mediante un Button,
        calcular los años cumplidos restando la fecha elegida con DateTime.Now.Year y
        mostrarlo en un Label.*/
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int edad = DateTime.Now.Year - fechanacimiento.Value.Year;

            label1.Text = "Tenés " + edad + " años";
        }
    }
}
