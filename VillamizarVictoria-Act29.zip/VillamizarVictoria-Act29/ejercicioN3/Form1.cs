﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicioN3
{
    public partial class Form1 : Form
    {
        /*8. Validador de Credenciales y Formato
        ● Consigna: Solicitar usuario y contraseña mediante TextBox (usando
        UseSystemPasswordChar = true). Un CheckBox &quot;Acepto términos&quot; debe habilitar
        (Enabled = true) el Button &quot;Ingresar&quot;. Si la clave coincide con &quot;admin123&quot;, mostrar
        éxito en una Label; de lo contrario, mostrar advertencia.*/ 
        public Form1()
        {
            InitializeComponent();

            button1.Enabled = false;
            contraseña.UseSystemPasswordChar = true;
        }

        private void terminos_CheckedChanged(object sender, EventArgs e)
        {
            button1.Enabled = terminos.Checked;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (contraseña.Text == "admin123")
            {
               label1.Text = "ingreso exitoso";
            }
            else
            {
                MessageBox.Show("contraseña incorrecta");
            }
        }
    }
}
