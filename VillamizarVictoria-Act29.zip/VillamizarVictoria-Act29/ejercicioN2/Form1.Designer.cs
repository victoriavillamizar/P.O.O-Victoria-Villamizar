﻿namespace ejercicioN2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.numericrojo = new System.Windows.Forms.NumericUpDown();
            this.numericverde = new System.Windows.Forms.NumericUpDown();
            this.numericazul = new System.Windows.Forms.NumericUpDown();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericrojo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericverde)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericazul)).BeginInit();
            this.SuspendLayout();
            // 
            // numericrojo
            // 
            this.numericrojo.Location = new System.Drawing.Point(93, 64);
            this.numericrojo.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericrojo.Name = "numericrojo";
            this.numericrojo.Size = new System.Drawing.Size(120, 20);
            this.numericrojo.TabIndex = 0;
            // 
            // numericverde
            // 
            this.numericverde.Location = new System.Drawing.Point(93, 90);
            this.numericverde.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericverde.Name = "numericverde";
            this.numericverde.Size = new System.Drawing.Size(120, 20);
            this.numericverde.TabIndex = 1;
            // 
            // numericazul
            // 
            this.numericazul.Location = new System.Drawing.Point(93, 116);
            this.numericazul.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericazul.Name = "numericazul";
            this.numericazul.Size = new System.Drawing.Size(120, 20);
            this.numericazul.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(93, 153);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "color";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.numericazul);
            this.Controls.Add(this.numericverde);
            this.Controls.Add(this.numericrojo);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numericrojo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericverde)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericazul)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numericrojo;
        private System.Windows.Forms.NumericUpDown numericverde;
        private System.Windows.Forms.NumericUpDown numericazul;
        private System.Windows.Forms.Button button1;
    }
}

