﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicioN3
{
    public partial class Form1 : Form
    {
        /*3. Gestor de Tareas Simplificado (Investigación: ListBox)
        ● Investigación: Investigar el control ListBox (propiedad Items, métodos Add() y
        RemoveAt()). Explicar brevemente su funcionamiento e incluir un ejemplo resuelto.
        ● Consigna: Armar una interfaz con un TextBox, un Button Agregar, un Button
        Eliminar; y un ListBox. Permitir añadir el texto tipeado a la lista y borrar el elemento
        que el usuario seleccione.
        */
        public Form1()
        {
            InitializeComponent();
        }

        private void agregar_Click(object sender, EventArgs e)
        {
            if (texto.Text != "")
            {
                lista.Items.Add(texto.Text);
                texto.Clear();
            }
        }

        private void eliminar_Click(object sender, EventArgs e)
        {
            if (lista.SelectedIndex != -1)
            {
                lista.Items.RemoveAt(lista.SelectedIndex);

            }
    }
        }
    }