﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicioN5
{
    public partial class Form1 : Form
    {
        /*5. Visor Dinámico de Imágenes (Investigación: PictureBox)
        ● Investigación: Investigar la clase PictureBox y sus propiedades ImageLocation y
        SizeMode.
        ● Consigna: Cargar en un ComboBox tres opciones. Al cambiar la selección mediante
        el evento SelectedIndexChanged, mostrar la imagen correspondiente dentro del
        PictureBox.
        */
        public Form1()
        {
            InitializeComponent();
        }

        int seleccion;

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            seleccion = comboBox1.SelectedIndex;

            if (seleccion == 0)
            {
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7XQ4uUesmyB4sf1KDnANccsbSPeF_iALr8EZUbSKDAA&s=10";
            }
            else if (seleccion == 1)
            {
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS33CDWNB9LsJJK4GE06jpYHWEmq4kIW7UrpXhC248IDw&s=10";
            }
            else if (seleccion == 2)
            {
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTDoKqEWlnpBbqNTYO-Pnzx3dKnZIgfAI8B8hGrscg0FA&s=10";
            }
        }
    }
}
