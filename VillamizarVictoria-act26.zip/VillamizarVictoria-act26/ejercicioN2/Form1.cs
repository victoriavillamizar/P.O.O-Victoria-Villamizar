﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicioN2
{
    public partial class Form1 : Form
    {
        /*2. Permitir el ingreso de dos números en controles de tipo TextBox y mediante
        dos controles de tipo RadioButton permitir seleccionar si queremos sumarlos o
        restarlos. Al presionar un botón mostrar en el título del Form el resultado de la
        operación.*/
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int numero1 = int.Parse(txtNumero1.Text);
            int numero2 = int.Parse(txtNumero2.Text);

            if (sumar.Checked)
            {
                int resultado = numero1 + numero2;
                this.Text = "Resultado: " + resultado;
            }

            if (restar.Checked)
            {
                int resultado = numero1 - numero2;
                this.Text = "Resultado: " + resultado;
            }
        }
    }
 }
