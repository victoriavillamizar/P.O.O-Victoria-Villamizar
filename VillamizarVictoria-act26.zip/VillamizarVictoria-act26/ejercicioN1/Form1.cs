﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicioN1
{
    public partial class Form1 : Form
    {
        /*1. Disponer tres objetos de la clase CheckBox con nombres de navegadores web.
        Cuando se presione un botón mostrar en el título del Form los programas
        seleccionados.*/
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string programas = "";

            if (checkOpera.Checked)
            {
                programas += "Opera";
            }

            if (checkGoogle.Checked)
            {
                programas += "Google Chrome";
            }

            if (checkFirefox.Checked)
            {
                programas += "Mozilla Firefox";
            }

            this.Text = programas;
        }
    }
    }

