﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicioN3
{
    public partial class Form1 : Form
    {
        /*3. Crear una aplicación que muestre en 6 objetos de la clase Label con
        algunos nombres de controles visuales contenidos en la pestaña de
        &quot;controles comunes&quot; del cuadro de herramientas*/
        public Form1()
        {
            InitializeComponent();
        }
    }
}
