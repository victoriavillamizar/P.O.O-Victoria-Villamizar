﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicioN1
{
    /*1. Elaborar una interfaz gráfica que muestre una calculadora (utilizar
    objetos de la clase Button y un objeto de la clase TextBox donde se
    mostrarían los resultados y se cargarían los datos), tener en cuenta que
    solo se debe implementar la interfaz y no la funcionalidad de una
    calculadora.*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {

        }
    }
}
