﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicioN2
{
    /**2. Disponer 7 objetos de la clase Button con los días de la semana. Fijar en
los atributos Text de cada botón los días de la semana. Al presionar un
botón mostrar en un objeto de la clase Label el día seleccionado.*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button8lunes_Click(object sender, EventArgs e)
        {
          label2.Text = "lunes";
        }
        private void button9martes_Click(object sender, EventArgs e)
        {
            label2.Text = "martes";
        }
        private void button10miercoles_Click(object sender, EventArgs e)
        {
            label2.Text = "miercoles";
        }
        private void button11jueves_Click(object sender, EventArgs e)
        {
            label2.Text = "jueves";
        }
        private void button12viernes_Click(object sender, EventArgs e)
        {
            label2.Text = "viernes";
        }
        private void button13sabado_Click(object sender, EventArgs e)
        {
            label2.Text = "sabado";
        }
        private void button14domingo_Click(object sender, EventArgs e)
        {
            label2.Text = "domingo";
        }

     
    }
}
