﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicioN4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //4. Se cargan por teclado tres números distintos. Mostrar por pantalla el mayor de ellos.
            int num1, num2, num3;
            string linea;

            Console.Write("ingrese primer numero: ");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.Write("ingrese segundo numero: ");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);

            Console.Write("ingrese tercer numero: ");
            linea = Console.ReadLine();
            num3 = int.Parse(linea);

            if (num1 > num2 && num1 > num3)
            {
                Console.WriteLine(" el "+ num1 +" es mayor que el resto : ");

            }
            else
            {
                if (num2 > num1 && num2 > num3)
                {
                    Console.WriteLine("el "+num2+ " es mayor que el resto : ");


                }
                else
                {
                    Console.WriteLine("el "+ num3 + " es mayor que el resto: ");


                }
                
            }
            Console.ReadKey();
        }
    }
}
