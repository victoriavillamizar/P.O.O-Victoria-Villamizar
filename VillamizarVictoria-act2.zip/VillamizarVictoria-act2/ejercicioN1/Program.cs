﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicioN1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //1. Realizar un programa que lea por teclado dos números, si el primero es mayor al segundo informar su suma y diferencia, en caso contrario informar el producto y la división del primero respecto al segundo.
            int num1, num2, resul1,resul2;
            string linea;

            Console.Write("ingrese primer numero: ");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.Write("ingrese segundo numero: ");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);

            if (num1 >= num2) {
                resul1 = num1 + num2;
                resul2 = num1 - num2;
                Console.WriteLine("la suma es: " + resul1);
                Console.WriteLine("la diferencia es: " + resul2);

            }
            else{
                resul1 = num1 * num2;
                resul2 = num1 / num2;
                Console.WriteLine("el producto es: " + resul1);
                Console.WriteLine ("la division es: " + resul2);

                Console.ReadKey();

            }

        }
    }
}
