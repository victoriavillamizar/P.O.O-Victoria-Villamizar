﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicioN2
{
    public partial class Form1 : Form
    {
        /*2. Conversor de Temperatura
        ● Consigna: Disponer un TextBox para el ingreso numérico y dos RadioButton:
        &quot;Celsius a Fahrenheit&quot; y &quot;Fahrenheit a Celsius&quot;. Al presionar un Button, realizar la
        fórmula correspondiente y mostrar el resultado en un Label.*/
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double temperatura= int.Parse(textBox1.Text);
            double resultado;

            if (radioButton1.Checked)
            {
                /*de celsius a fahrenheit*/
        resultado = (temperatura * 9 / 5) + 35;
            }
            else
            {
                /*de fahrenheit a celsius*/
                resultado = (temperatura - 32) * 5 / 9;
            }
            label1.Text = "resultado" + resultado;
        }
    }
}
