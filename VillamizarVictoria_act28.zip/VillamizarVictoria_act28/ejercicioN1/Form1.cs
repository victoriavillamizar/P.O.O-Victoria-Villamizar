﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicioN1
{
    public partial class Form1 : Form
    {
        /*1.1. Calculadora de Promedio de Notas
        ● Consigna: Crear un formulario con tres TextBox para ingresar notas y un Button
        &quot;Calcular&quot;. Convertir los valores con int.Parse() o double.Parse() y mostrar en una
        Label el promedio. Si la nota es mayor o igual a 6, cambiar el color del texto de la
        etiqueta a verde; de lo contrario, a rojo.*/
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalcular_Click(object sender, EventArgs e)
        {
            int num1= int.Parse(valor1.Text);
            int num2= int.Parse(valor1.Text);
            int num3= int.Parse(valor1.Text);

            double promedio = (num1+num2+num3)/3.0;
            label1.Text = "promedio:" + promedio;

            if (promedio >= 6)
            {
                label1.ForeColor = Color.Green;
            }
            else
            {
                label1.ForeColor = Color.Red;
            }
        }
    }
}
