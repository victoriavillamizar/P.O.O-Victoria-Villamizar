﻿namespace ejercicioN3
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.playa = new System.Windows.Forms.RadioButton();
            this.montaña = new System.Windows.Forms.RadioButton();
            this.ciudad = new System.Windows.Forms.RadioButton();
            this.tiempo = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.resultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // playa
            // 
            this.playa.AutoSize = true;
            this.playa.Location = new System.Drawing.Point(52, 38);
            this.playa.Name = "playa";
            this.playa.Size = new System.Drawing.Size(50, 17);
            this.playa.TabIndex = 0;
            this.playa.TabStop = true;
            this.playa.Text = "playa";
            this.playa.UseVisualStyleBackColor = true;
            // 
            // montaña
            // 
            this.montaña.AutoSize = true;
            this.montaña.Location = new System.Drawing.Point(52, 75);
            this.montaña.Name = "montaña";
            this.montaña.Size = new System.Drawing.Size(66, 17);
            this.montaña.TabIndex = 1;
            this.montaña.TabStop = true;
            this.montaña.Text = "montaña";
            this.montaña.UseVisualStyleBackColor = true;
            // 
            // ciudad
            // 
            this.ciudad.AutoSize = true;
            this.ciudad.Location = new System.Drawing.Point(52, 109);
            this.ciudad.Name = "ciudad";
            this.ciudad.Size = new System.Drawing.Size(57, 17);
            this.ciudad.TabIndex = 2;
            this.ciudad.TabStop = true;
            this.ciudad.Text = "ciudad";
            this.ciudad.UseVisualStyleBackColor = true;
            // 
            // tiempo
            // 
            this.tiempo.FormattingEnabled = true;
            this.tiempo.Items.AddRange(new object[] {
            "3 dias",
            "7 dias",
            "15 dias"});
            this.tiempo.Location = new System.Drawing.Point(52, 153);
            this.tiempo.Name = "tiempo";
            this.tiempo.Size = new System.Drawing.Size(121, 21);
            this.tiempo.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(52, 199);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "confirmar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // resultado
            // 
            this.resultado.AutoSize = true;
            this.resultado.Location = new System.Drawing.Point(49, 240);
            this.resultado.Name = "resultado";
            this.resultado.Size = new System.Drawing.Size(0, 13);
            this.resultado.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.resultado);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tiempo);
            this.Controls.Add(this.ciudad);
            this.Controls.Add(this.montaña);
            this.Controls.Add(this.playa);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton playa;
        private System.Windows.Forms.RadioButton montaña;
        private System.Windows.Forms.RadioButton ciudad;
        private System.Windows.Forms.ComboBox tiempo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label resultado;
    }
}

