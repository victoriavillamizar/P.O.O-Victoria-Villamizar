﻿namespace ejercicioN2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboGenero = new System.Windows.Forms.ComboBox();
            this.checkBenvivo = new System.Windows.Forms.CheckBox();
            this.checkBcomprardiscos = new System.Windows.Forms.CheckBox();
            this.checkBspotify = new System.Windows.Forms.CheckBox();
            this.titulo = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.resultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // comboGenero
            // 
            this.comboGenero.FormattingEnabled = true;
            this.comboGenero.Items.AddRange(new object[] {
            "reggaeton viejo",
            "drip",
            "rock nacional",
            "under",
            "pop"});
            this.comboGenero.Location = new System.Drawing.Point(34, 64);
            this.comboGenero.Name = "comboGenero";
            this.comboGenero.Size = new System.Drawing.Size(143, 21);
            this.comboGenero.TabIndex = 0;
            // 
            // checkBenvivo
            // 
            this.checkBenvivo.AutoSize = true;
            this.checkBenvivo.Location = new System.Drawing.Point(38, 111);
            this.checkBenvivo.Name = "checkBenvivo";
            this.checkBenvivo.Size = new System.Drawing.Size(108, 17);
            this.checkBenvivo.TabIndex = 1;
            this.checkBenvivo.Text = "escuchar en vivo";
            this.checkBenvivo.UseVisualStyleBackColor = true;
            // 
            // checkBcomprardiscos
            // 
            this.checkBcomprardiscos.AutoSize = true;
            this.checkBcomprardiscos.Location = new System.Drawing.Point(38, 145);
            this.checkBcomprardiscos.Name = "checkBcomprardiscos";
            this.checkBcomprardiscos.Size = new System.Drawing.Size(97, 17);
            this.checkBcomprardiscos.TabIndex = 2;
            this.checkBcomprardiscos.Text = "comprar discos";
            this.checkBcomprardiscos.UseVisualStyleBackColor = true;
            // 
            // checkBspotify
            // 
            this.checkBspotify.AutoSize = true;
            this.checkBspotify.Location = new System.Drawing.Point(38, 179);
            this.checkBspotify.Name = "checkBspotify";
            this.checkBspotify.Size = new System.Drawing.Size(118, 17);
            this.checkBspotify.TabIndex = 3;
            this.checkBspotify.Text = "escuchar en spotify";
            this.checkBspotify.UseVisualStyleBackColor = true;
            // 
            // titulo
            // 
            this.titulo.AutoSize = true;
            this.titulo.Location = new System.Drawing.Point(35, 28);
            this.titulo.Name = "titulo";
            this.titulo.Size = new System.Drawing.Size(127, 13);
            this.titulo.TabIndex = 4;
            this.titulo.Text = "ENCUESTA DE MUSICA";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(34, 220);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "mostrar preferencias";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // resultado
            // 
            this.resultado.AutoSize = true;
            this.resultado.Location = new System.Drawing.Point(35, 261);
            this.resultado.Name = "resultado";
            this.resultado.Size = new System.Drawing.Size(0, 13);
            this.resultado.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.resultado);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.titulo);
            this.Controls.Add(this.checkBspotify);
            this.Controls.Add(this.checkBcomprardiscos);
            this.Controls.Add(this.checkBenvivo);
            this.Controls.Add(this.comboGenero);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboGenero;
        private System.Windows.Forms.CheckBox checkBenvivo;
        private System.Windows.Forms.CheckBox checkBcomprardiscos;
        private System.Windows.Forms.CheckBox checkBspotify;
        private System.Windows.Forms.Label titulo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label resultado;
    }
}

