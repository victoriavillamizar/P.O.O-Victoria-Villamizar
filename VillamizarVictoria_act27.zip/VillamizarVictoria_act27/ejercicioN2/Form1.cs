﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicioN2
{
    public partial class Form1 : Form
    {
        /*Actividad 2: Encuesta de Preferencias de Música
        Problema:
        Una aplicación quiere conocer los gustos musicales de los usuarios.
        Requisitos:
        ● Mostrar un ComboBox con 5 géneros musicales distintos.
        ● Incluir tres CheckBox que representen actividades relacionadas (por ejemplo:
        &quot;Escuchar en vivo&quot;, &quot;Escuchar en streaming&quot;, &quot;Comprar discos&quot;).
        ● Al presionar un botón &quot;Mostrar Preferencias&quot;, en un Label se debe mostrar el género
        seleccionado y las actividades marcadas.*/
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string genero = comboGenero.Text;
            string actividades = "";

            if (checkBenvivo .Checked)
            {
                actividades += "escuchar en vivo, ";
            }

            if (checkBcomprardiscos.Checked)
            {
                actividades += "comprar discos, ";
            }

            if (checkBspotify.Checked)
            {
                actividades += "escuchar en spotify";
            }

            resultado.Text = "genero: " + genero + " actividades: " + actividades;
        }

    }
    }

