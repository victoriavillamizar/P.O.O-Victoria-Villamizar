﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicioN5
{
    public partial class Form1 : Form
    {
        /*Actividad 5: Configuración de Suscripción
        Problema:
        Una aplicación ofrece distintos niveles de suscripción.
        Requisitos:
        ● Usar un ComboBox para elegir el tipo de plan: &quot;Gratis&quot;, &quot;Básico&quot;, &quot;Premium&quot;.
        ● Incluir dos CheckBox para elegir servicios adicionales (por ejemplo: &quot;Soporte
        técnico&quot;, &quot;Acceso anticipado&quot;).
        ● Al presionar el botón &quot;Guardar&quot;, se debe mostrar en un Label un resumen con el
        plan y los servicios elegidos.*/
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string plan = comboBoxplan.Text;
            string serviciosadicionales = "";

            if (checkacceso.Checked)
            {
                serviciosadicionales += "acceso anticipado, ";
            }

            if (checksoporte.Checked)
            {
                serviciosadicionales += "soporte tecnico, ";
            }
            resultado.Text = "plan elegido: " + plan + ".  " + "servicios adicionales: " + serviciosadicionales;
        }
    }
}

