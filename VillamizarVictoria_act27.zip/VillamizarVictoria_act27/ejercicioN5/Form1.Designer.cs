﻿namespace ejercicioN5
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBoxplan = new System.Windows.Forms.ComboBox();
            this.checkacceso = new System.Windows.Forms.CheckBox();
            this.checksoporte = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.resultado = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // comboBoxplan
            // 
            this.comboBoxplan.FormattingEnabled = true;
            this.comboBoxplan.Items.AddRange(new object[] {
            "gratis",
            "basico",
            "premium"});
            this.comboBoxplan.Location = new System.Drawing.Point(37, 54);
            this.comboBoxplan.Name = "comboBoxplan";
            this.comboBoxplan.Size = new System.Drawing.Size(121, 21);
            this.comboBoxplan.TabIndex = 0;
            // 
            // checkacceso
            // 
            this.checkacceso.AutoSize = true;
            this.checkacceso.Location = new System.Drawing.Point(39, 81);
            this.checkacceso.Name = "checkacceso";
            this.checkacceso.Size = new System.Drawing.Size(113, 17);
            this.checkacceso.TabIndex = 1;
            this.checkacceso.Text = "acceso anticipado";
            this.checkacceso.UseVisualStyleBackColor = true;
            // 
            // checksoporte
            // 
            this.checksoporte.AutoSize = true;
            this.checksoporte.Location = new System.Drawing.Point(39, 104);
            this.checksoporte.Name = "checksoporte";
            this.checksoporte.Size = new System.Drawing.Size(99, 17);
            this.checksoporte.TabIndex = 2;
            this.checksoporte.Text = "soporte tecnico";
            this.checksoporte.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(37, 127);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "guardar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // resultado
            // 
            this.resultado.AutoSize = true;
            this.resultado.Location = new System.Drawing.Point(37, 157);
            this.resultado.Name = "resultado";
            this.resultado.Size = new System.Drawing.Size(0, 13);
            this.resultado.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "elegir tipo de plan";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.resultado);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.checksoporte);
            this.Controls.Add(this.checkacceso);
            this.Controls.Add(this.comboBoxplan);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxplan;
        private System.Windows.Forms.CheckBox checkacceso;
        private System.Windows.Forms.CheckBox checksoporte;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label resultado;
        private System.Windows.Forms.Label label1;
    }
}

