﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicioN1
{
    public partial class Form1 : Form
    {
        /*Actividad 1: Registro de Usuario Simple
        Problema:
        Se desea crear un formulario para registrar usuarios en un sistema.
        Requisitos:
        ● Mostrar etiquetas (Label) para &quot;Nombre&quot;, &quot;Apellido&quot; y &quot;Correo&quot;.
        ● Permitir que el usuario escriba los datos en TextBox.
        ● Incluir un botón &quot;Registrar&quot; que, al presionarlo, muestra en un Label un mensaje con
        los datos ingresados concatenados.*/
        public Form1()
        {
            InitializeComponent();
        }

        private void registrar_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text;
            string apellido = txtApellido.Text;
            string correo = txtCorreo.Text;
            info.Text = "usuario registrado = " + nombre + " " + apellido + "-"+ correo;
        }
    }
}
