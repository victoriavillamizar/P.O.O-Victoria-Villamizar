﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicioN4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
          /*4. Temporizador de Clics (Investigación: Timer)
        ● Investigación: Explicar el componente Timer (propiedades Interval, Enabled y
        evento Tick) con un breve ejemplo explicativo.
        ● Consigna: Crear un mini-juego donde un Button cuente cuántos clics realiza el
        usuario en 10 segundos. Al finalizar el tiempo mediante el Timer, deshabilitar el
        botón (Enabled = false) y mostrar el puntaje acumulado en un MessageBox.Show.*/
            InitializeComponent();
        }

        int clics = 0;
        int segundos = 10;

        private void button1_Click(object sender, EventArgs e)
        {
            clics = 0;
            segundos = 10;

            button2.Enabled = true;
            timer1.Enabled = true;
            timer1.Interval = 1000;
            timer1.Start();
            button1.Enabled = false;
            timer1.Tick += new EventHandler(timer1_Tick);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            clics++;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            segundos--;

            if (segundos == 0)
            {
                timer1.Enabled = false;
                button2.Enabled = false;
                button1.Enabled = true;
                timer1.Stop();
                MessageBox.Show("tu puntaje fue: " + clics);
            }
        }
    }
}
